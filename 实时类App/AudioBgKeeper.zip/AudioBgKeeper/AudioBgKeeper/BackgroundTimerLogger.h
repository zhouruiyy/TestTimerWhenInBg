#import <Foundation/Foundation.h>

@interface BackgroundTimerLogger : NSObject
- (instancetype)initWithLabel:(NSString *)label
                   intervalMs:(double)intervalMs
              durationSeconds:(NSTimeInterval)durationSeconds
                       fileURL:(NSURL *)fileURL;

- (instancetype)initWithLabel:(NSString *)label
                   intervalMs:(double)intervalMs
              durationSeconds:(NSTimeInterval)durationSeconds
                       fileURL:(NSURL *)fileURL
          flushIntervalSeconds:(NSTimeInterval)flushIntervalSeconds;

- (void)start;
- (void)stop;
@end 