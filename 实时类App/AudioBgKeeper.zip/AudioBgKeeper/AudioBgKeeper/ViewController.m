//
//  ViewController.m
//  AudioBgKeeper
//
//  Created by ZhouRui on 2025/8/13.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ViewController ()
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor systemBackgroundColor];

    UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeSystem];
    [btn1 setTitle:@"Start Audio BG 40ms" forState:UIControlStateNormal];
    btn1.frame = CGRectMake(40, 140, 240, 44);
    [btn1 addTarget:self action:@selector(onStartAudioBG) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];

    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeSystem];
    [btn2 setTitle:@"Start QoS Thread 40ms" forState:UIControlStateNormal];
    btn2.frame = CGRectMake(40, 200, 240, 44);
    [btn2 addTarget:self action:@selector(onStartQoSThread) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];

    UIButton *btn4 = [UIButton buttonWithType:UIButtonTypeSystem];
    [btn4 setTitle:@"Start Nice Thread 40ms" forState:UIControlStateNormal];
    btn4.frame = CGRectMake(40, 260, 240, 44);
    [btn4 addTarget:self action:@selector(onStartNiceThread) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn4];

    UIButton *btn3 = [UIButton buttonWithType:UIButtonTypeSystem];
    [btn3 setTitle:@"Stop All" forState:UIControlStateNormal];
    btn3.frame = CGRectMake(40, 320, 240, 44);
    [btn3 addTarget:self action:@selector(onStopAll) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn3];
}

- (void)onStartAudioBG {
    AppDelegate *app = (AppDelegate *)UIApplication.sharedApplication.delegate;
    if ([app respondsToSelector:@selector(selectAudioBGForNextBackground)]) {
        [app selectAudioBGForNextBackground];
    }
}

- (void)onStartQoSThread {
    AppDelegate *app = (AppDelegate *)UIApplication.sharedApplication.delegate;
    if ([app respondsToSelector:@selector(selectQoSThreadForNextBackground)]) {
        [app selectQoSThreadForNextBackground];
    }
}

- (void)onStartNiceThread {
    AppDelegate *app = (AppDelegate *)UIApplication.sharedApplication.delegate;
    if ([app respondsToSelector:@selector(selectNiceThreadForNextBackground)]) {
        [app selectNiceThreadForNextBackground];
    }
}

- (void)onStopAll {
    AppDelegate *app = (AppDelegate *)UIApplication.sharedApplication.delegate;
    if ([app respondsToSelector:@selector(stopAllTests)]) {
        [app stopAllTests];
    }
}

@end
