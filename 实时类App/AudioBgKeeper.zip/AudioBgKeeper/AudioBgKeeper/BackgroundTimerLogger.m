#import "BackgroundTimerLogger.h"
#import <mach/mach_time.h>
#import <os/lock.h>

@interface BackgroundTimerLogger () {
    dispatch_source_t _timer;
    dispatch_source_t _flushTimer;
    dispatch_queue_t _queue;
    BOOL _running;
    uint64_t _t0, _last;
    NSMutableData *_log;
    os_unfair_lock _lock;
}
@property (nonatomic, copy) NSString *label;
@property (nonatomic) double intervalMs;
@property (nonatomic) NSTimeInterval durationSeconds;
@property (nonatomic, strong) NSURL *fileURL;
@property (nonatomic) NSTimeInterval flushIntervalSeconds;
@end

@implementation BackgroundTimerLogger

- (instancetype)initWithLabel:(NSString *)label
                   intervalMs:(double)intervalMs
              durationSeconds:(NSTimeInterval)durationSeconds
                       fileURL:(NSURL *)fileURL {
    return [self initWithLabel:label intervalMs:intervalMs durationSeconds:durationSeconds fileURL:fileURL flushIntervalSeconds:0];
}

- (instancetype)initWithLabel:(NSString *)label
                   intervalMs:(double)intervalMs
              durationSeconds:(NSTimeInterval)durationSeconds
                       fileURL:(NSURL *)fileURL
          flushIntervalSeconds:(NSTimeInterval)flushIntervalSeconds {
    if (self = [super init]) {
        _label = [label copy];
        _intervalMs = intervalMs;
        _durationSeconds = durationSeconds;
        _fileURL = fileURL;
        _flushIntervalSeconds = flushIntervalSeconds;
        _queue = dispatch_get_global_queue(QOS_CLASS_USER_INTERACTIVE, 0);
        _lock = OS_UNFAIR_LOCK_INIT;
        _log = [NSMutableData data];
    }
    return self;
}

static inline uint64_t now_ticks(void) { return mach_continuous_time(); }
static inline double ticks_to_ms(uint64_t dt) {
    static mach_timebase_info_data_t tb; static dispatch_once_t once;
    dispatch_once(&once, ^{ mach_timebase_info(&tb); });
    long double ns = (long double)dt * tb.numer / tb.denom;
    return (double)(ns / 1e6);
}

- (void)start {
    NSLog(@"[AudioBG] start");
    if (_running) return;
    _running = YES;

    NSString *header = [NSString stringWithFormat:@"label=%@ intervalMs=%.3f duration=%.3fs\n", self.label, self.intervalMs, self.durationSeconds];
    [_log appendData:[header dataUsingEncoding:NSUTF8StringEncoding]];
    [_log appendData:[@"t(ms),dt(ms)\n" dataUsingEncoding:NSUTF8StringEncoding]];

    _t0 = now_ticks(); _last = _t0;
    double sec = self.intervalMs / 1000.0;
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, _queue);
    dispatch_source_set_timer(_timer,
                              dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)),
                              (uint64_t)(sec * NSEC_PER_SEC),
                              0);
    __unsafe_unretained typeof(self) uSelf = self;
    dispatch_source_set_event_handler(_timer, ^{
        if (!uSelf || !uSelf->_running) return;
        uint64_t t = now_ticks();
        double tMs = ticks_to_ms(t - uSelf->_t0);
        double dtMs = ticks_to_ms(t - uSelf->_last);
        uSelf->_last = t;

        NSString *line = [NSString stringWithFormat:@"%.3f,%.3f\n", tMs, dtMs];
        os_unfair_lock_lock(&uSelf->_lock);
        [uSelf->_log appendData:[line dataUsingEncoding:NSUTF8StringEncoding]];
        os_unfair_lock_unlock(&uSelf->_lock);

        if (tMs >= uSelf.durationSeconds * 1000.0) [uSelf stop];
    });
    dispatch_resume(_timer);

    if (self.flushIntervalSeconds > 0) {
        _flushTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, _queue);
        dispatch_source_set_timer(_flushTimer,
                                  dispatch_time(DISPATCH_TIME_NOW, (int64_t)(self.flushIntervalSeconds * NSEC_PER_SEC)),
                                  (uint64_t)(self.flushIntervalSeconds * NSEC_PER_SEC),
                                  0);
        dispatch_source_set_event_handler(_flushTimer, ^{
            [uSelf flushAppendToFile];
        });
        dispatch_resume(_flushTimer);
    }
}

- (void)flushAppendToFile {
    NSLog(@"[AudioBG] flushAppendToFile");
    os_unfair_lock_lock(&_lock);
    NSData *chunk = [_log copy];
    [_log setLength:0];
    os_unfair_lock_unlock(&_lock);

    if (chunk.length == 0) return;
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:self.fileURL.path]) {
        [chunk writeToURL:self.fileURL atomically:YES];
    } else {
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:self.fileURL.path];
        [fh seekToEndOfFile];
        [fh writeData:chunk];
        [fh closeFile];
    }
}

- (void)stop {
    NSLog(@"[AudioBG] stop");
    if (!_running) return;
    _running = NO;
    if (_timer) { dispatch_source_cancel(_timer); _timer = nil; }
    if (_flushTimer) { dispatch_source_cancel(_flushTimer); _flushTimer = nil; }
    [self flushAppendToFile];
}

@end 