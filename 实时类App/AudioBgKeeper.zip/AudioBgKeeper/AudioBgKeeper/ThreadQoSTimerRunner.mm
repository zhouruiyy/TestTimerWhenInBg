#import "ThreadQoSTimerRunner.h"
#import <mach/mach_time.h>
#import <os/lock.h>
#import <pthread.h>

@interface ThreadQoSTimerRunner () {
	pthread_t _thread;
	BOOL _running;
	NSMutableData *_log;
	os_unfair_lock _lock;
}
@property (nonatomic, copy) NSString *label;
@property (nonatomic) double intervalMs;
@property (nonatomic) NSTimeInterval durationSeconds;
@property (nonatomic, strong) NSURL *fileURL;
@property (nonatomic) NSTimeInterval flushIntervalSeconds;
@end

@implementation ThreadQoSTimerRunner

- (instancetype)initWithLabel:(NSString *)label
                   intervalMs:(double)intervalMs
              durationSeconds:(NSTimeInterval)durationSeconds
                       fileURL:(NSURL *)fileURL
          flushIntervalSeconds:(NSTimeInterval)flushIntervalSeconds {
	if (self = [super init]) {
		_label = [label copy];
		_intervalMs = intervalMs;
		_durationSeconds = durationSeconds;
		_fileURL = fileURL;
		_flushIntervalSeconds = flushIntervalSeconds;
		_lock = OS_UNFAIR_LOCK_INIT;
		_log = [NSMutableData data];
		_running = NO;
	}
	return self;
}

static inline uint64_t now_ticks(void) { return mach_continuous_time(); }
static inline double ticks_to_ms(uint64_t dt) {
	static mach_timebase_info_data_t tb; static dispatch_once_t once;
	dispatch_once(&once, ^{ mach_timebase_info(&tb); });
	long double ns = (long double)dt * tb.numer / tb.denom;
	return (double)(ns / 1e6);
}
static inline uint64_t ns_to_ticks(uint64_t ns) {
	static mach_timebase_info_data_t tb; static dispatch_once_t once;
	dispatch_once(&once, ^{ mach_timebase_info(&tb); });
	return (uint64_t)(((__uint128_t)ns * tb.denom) / tb.numer);
}
static inline uint64_t seconds_to_ticks(double sec) {
	return ns_to_ticks((uint64_t)(sec * 1e9));
}

static void *qos_thread_func(void *arg) {
	ThreadQoSTimerRunner *runner = (__bridge ThreadQoSTimerRunner *)arg;
	pthread_set_qos_class_self_np(QOS_CLASS_USER_INITIATED, 0);

	double intervalSec = runner.intervalMs / 1000.0;
	uint64_t t0 = now_ticks();
	uint64_t last = t0;
	uint64_t startTicks = now_ticks();
	uint64_t nextFlushTicks = startTicks + (runner.flushIntervalSeconds > 0 ? seconds_to_ticks(runner.flushIntervalSeconds) : 0);

	while (runner->_running) {
		struct timespec ts;
		ts.tv_sec = (time_t)intervalSec;
		ts.tv_nsec = (long)((intervalSec - ts.tv_sec) * 1e9);
		nanosleep(&ts, NULL);

		uint64_t now = now_ticks();
		double tMs = ticks_to_ms(now - t0);
		double dtMs = ticks_to_ms(now - last);
		last = now;

		NSString *line = [NSString stringWithFormat:@"%.3f,%.3f\n", tMs, dtMs];
		os_unfair_lock_lock(&runner->_lock);
		[runner->_log appendData:[line dataUsingEncoding:NSUTF8StringEncoding]];
		os_unfair_lock_unlock(&runner->_lock);

		if (runner.flushIntervalSeconds > 0 && now >= nextFlushTicks) {
			[runner flushAppendToFile];
			nextFlushTicks += seconds_to_ticks(runner.flushIntervalSeconds);
		}

		if (tMs >= runner.durationSeconds * 1000.0) {
			runner->_running = NO;
			break;
		}
	}
	[runner flushAppendToFile];
	return NULL;
}

- (void)start {
	if (_running) return;
	_running = YES;

	NSString *header = [NSString stringWithFormat:@"label=%@ intervalMs=%.3f duration=%.3fs\n", self.label, self.intervalMs, self.durationSeconds];
	[_log appendData:[header dataUsingEncoding:NSUTF8StringEncoding]];
	[_log appendData:[@"t(ms),dt(ms)\n" dataUsingEncoding:NSUTF8StringEncoding]];
	[self flushAppendToFile];

	pthread_create(&_thread, NULL, qos_thread_func, (__bridge void *)self);
}

- (void)flushAppendToFile {
	os_unfair_lock_lock(&_lock);
	NSData *chunk = [_log copy];
	[_log setLength:0];
	os_unfair_lock_unlock(&_lock);

	if (chunk.length == 0) return;
	NSFileManager *fm = [NSFileManager defaultManager];
	if (![fm fileExistsAtPath:self.fileURL.path]) {
		[chunk writeToURL:self.fileURL atomically:YES];
	} else {
		NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:self.fileURL.path];
		[fh seekToEndOfFile];
		[fh writeData:chunk];
		[fh closeFile];
	}
}

- (void)stop {
	if (!_running) return;
	_running = NO;
	if (_thread) {
		pthread_join(_thread, NULL);
		_thread = 0;
	}
	[self flushAppendToFile];
}

@end 
