#import "AudioBackgroundKeeper.h"
@import AVFoundation;

@interface AudioBackgroundKeeper ()
@property (nonatomic, strong) AVAudioEngine *engine;
@property (nonatomic, strong) AVAudioPlayerNode *player;
@property (nonatomic, assign) BOOL running;
@end

@implementation AudioBackgroundKeeper

- (BOOL)startWithError:(NSError **)error {
    if (self.running) return YES;

    AVAudioSession *s = AVAudioSession.sharedInstance;
    if (![s setCategory:AVAudioSessionCategoryPlayback
             withOptions:AVAudioSessionCategoryOptionMixWithOthers
                   error:error]) return NO;

    [s setPreferredSampleRate:48000 error:nil];
    [s setPreferredIOBufferDuration:0.04 error:nil];
    if (![s setActive:YES error:error]) return NO;

    self.engine = [[AVAudioEngine alloc] init];
    self.player = [[AVAudioPlayerNode alloc] init];
    [self.engine attachNode:self.player];

    AVAudioFormat *fmt = [[AVAudioFormat alloc] initStandardFormatWithSampleRate:48000 channels:2];
    [self.engine connect:self.player to:self.engine.mainMixerNode format:fmt];

    AVAudioFrameCount frames = (AVAudioFrameCount)(fmt.sampleRate * 0.5);
    AVAudioPCMBuffer *buf = [[AVAudioPCMBuffer alloc] initWithPCMFormat:fmt frameCapacity:frames];
    buf.frameLength = frames;
    float *l = buf.floatChannelData[0];
    float *r = buf.floatChannelData[1];
    for (AVAudioFrameCount i = 0; i < frames; i++) { l[i] = 1e-6f; r[i] = 1e-6f; }

    if (![self.engine startAndReturnError:error]) return NO;
    [self.player play];
    [self.player scheduleBuffer:buf atTime:nil options:AVAudioPlayerNodeBufferLoops completionHandler:nil];

    self.running = YES;
    return YES;
}

- (void)stop {
    if (!self.running) return;
    [self.player stop];
    [self.engine stop];
    [AVAudioSession.sharedInstance setActive:NO error:nil];
    self.engine = nil;
    self.player = nil;
    self.running = NO;
}

- (BOOL)isRunning { return self.running; }

@end 