//
//  AppDelegate.m
//  AudioBgKeeper
//
//  Created by ZhouRui on 2025/8/13.
//

#import "AppDelegate.h"
#import "AudioBackgroundKeeper.h"
#import "BackgroundTimerLogger.h"
#import "ThreadQoSTimerRunner.h"
#import "NiceThreadTimerRunner.h"

typedef NS_ENUM(NSInteger, TestMode) { TestModeNone=0, TestModeAudioBG, TestModeQoSThread };

@interface AppDelegate ()
@property (nonatomic, strong) AudioBackgroundKeeper *audioKeeper;
@property (nonatomic, strong) BackgroundTimerLogger *logger;
@property (nonatomic, strong) ThreadQoSTimerRunner *qosRunner;
@property (nonatomic, strong) NiceThreadTimerRunner *niceRunner;
@property (nonatomic) TestMode pendingMode;
@property (nonatomic) BOOL isRunning; // 可选：避免重复启动
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.audioKeeper = [AudioBackgroundKeeper new];
    return YES;
}

#pragma mark - UISceneSession lifecycle

- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}

- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Only start when selected via UI, or keep as manual start
}

- (void)selectAudioBGForNextBackground { self.pendingMode = TestModeAudioBG; }
- (void)selectQoSThreadForNextBackground { self.pendingMode = TestModeQoSThread; }
- (void)selectNiceThreadForNextBackground { self.pendingMode = TestModeQoSThread+1; /* temp marker */ }
- (void)clearSelection { self.pendingMode = TestModeNone; }

- (void)startPendingModeIfAny {
    if (self.isRunning) return;
    switch (self.pendingMode) {
        case TestModeAudioBG:
            [self startAudioAndLoggerForBackground];
            self.isRunning = YES;
            break;
        case TestModeQoSThread:
            [self startQoSThreadTimerTest];
            self.isRunning = YES;
            break;
        default:
            // Treat marker as NiceThread
            [self startNiceThreadTimerTest];
            self.isRunning = YES;
            break;
    }
    self.pendingMode = TestModeNone;
}

- (void)startAudioAndLoggerForBackground {
    NSError *err = nil;
    if (![self.audioKeeper isRunning]) {
        BOOL ok = [self.audioKeeper startWithError:&err];
        NSLog(@"[AudioBG] Audio start: %@ (%@)", ok ? @"OK" : @"FAIL", err);
    }
    NSURL *docs = [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] firstObject];
    NSDateFormatter *df = [NSDateFormatter new]; df.dateFormat = @"yyyyMMdd_HHmmss";
    NSURL *fileURL = [docs URLByAppendingPathComponent:[NSString stringWithFormat:@"audio_bg_timer_%@.csv", [df stringFromDate:[NSDate date]]]];
    self.logger = [[BackgroundTimerLogger alloc] initWithLabel:@"AudioBG-40ms"
                                                    intervalMs:40.0
                                               durationSeconds:3600.0
                                                        fileURL:fileURL
                                           flushIntervalSeconds:30.0];
    [self.logger start];
}

- (void)startQoSThreadTimerTest {
    NSURL *docs = [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] firstObject];
    NSDateFormatter *df = [NSDateFormatter new]; df.dateFormat = @"yyyyMMdd_HHmmss";
    NSURL *fileURL = [docs URLByAppendingPathComponent:[NSString stringWithFormat:@"qos_thread_timer_%@.csv", [df stringFromDate:[NSDate date]]]];
    self.qosRunner = [[ThreadQoSTimerRunner alloc] initWithLabel:@"QoSThread-40ms"
                                                      intervalMs:40.0
                                                 durationSeconds:3600.0
                                                          fileURL:fileURL
                                             flushIntervalSeconds:30.0];
    [self.qosRunner start];
    NSLog(@"[QoSThread] started");
}

- (void)startNiceThreadTimerTest {
    NSURL *docs = [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] firstObject];
    NSDateFormatter *df = [NSDateFormatter new]; df.dateFormat = @"yyyyMMdd_HHmmss";
    NSURL *fileURL = [docs URLByAppendingPathComponent:[NSString stringWithFormat:@"nice_thread_timer_%@.csv", [df stringFromDate:[NSDate date]]]];
    self.niceRunner = [[NiceThreadTimerRunner alloc] initWithLabel:@"NiceThread-40ms"
                                                        intervalMs:40.0
                                                   durationSeconds:3600.0
                                                            fileURL:fileURL
                                               flushIntervalSeconds:30.0
                                                          niceValue:-20];
    [self.niceRunner start];
    NSLog(@"[NiceThread] started with nice=-20");
}

- (void)stopAllTests {
    if (self.logger) { [self.logger stop]; self.logger = nil; }
    if (self.qosRunner) { [self.qosRunner stop]; self.qosRunner = nil; }
    if (self.niceRunner) { [self.niceRunner stop]; self.niceRunner = nil; }
    if (self.audioKeeper && [self.audioKeeper isRunning]) { [self.audioKeeper stop]; }
    NSLog(@"[Tests] stopped all");
}

@end
