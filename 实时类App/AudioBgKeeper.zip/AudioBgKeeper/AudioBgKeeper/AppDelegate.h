//
//  AppDelegate.h
//  AudioBgKeeper
//
//  Created by ZhouRui on 2025/8/13.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
- (void)startAudioAndLoggerForBackground;
- (void)startQoSThreadTimerTest;
- (void)startNiceThreadTimerTest;
- (void)stopAllTests;
- (void)setModeAudioBG;
- (void)setModeQoSThread;
- (void)selectAudioBGForNextBackground;
- (void)selectQoSThreadForNextBackground;
- (void)selectNiceThreadForNextBackground;
- (void)clearSelection;
- (void)startPendingModeIfAny; // 由后台钩子调用
@end

