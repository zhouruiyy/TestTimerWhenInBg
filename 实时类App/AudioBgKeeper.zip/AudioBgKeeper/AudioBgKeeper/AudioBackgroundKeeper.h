#import <Foundation/Foundation.h>

@interface AudioBackgroundKeeper : NSObject
- (BOOL)startWithError:(NSError **)error;
- (void)stop;
- (BOOL)isRunning;
@end 