//
//  SceneDelegate.h
//  AudioBgKeeper
//
//  Created by ZhouRui on 2025/8/13.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

